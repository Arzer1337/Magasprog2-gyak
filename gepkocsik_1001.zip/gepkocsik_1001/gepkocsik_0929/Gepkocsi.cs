﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gepkocsik_0929
{
    internal class Gepkocsi
    {
		private string rendszam;
		public string Rendszam
		{
			get { return rendszam; }
			set 
			{
				if (string.IsNullOrEmpty(value) || value.Length != 6)
				{
					throw new Exception("Hiba");
				}

				rendszam = value; 
			}
		}

		private string marka;
		public string Marka
		{
			get { return marka; }
			set 
			{
				if (string.IsNullOrEmpty(value))
				{
					throw new Exception("hiba");
				}

				marka = value; 
			}
		}

		private string modell;
		public string Modell
		{
			get
			{
				return modell;
			}
			set
			{
                if (string.IsNullOrEmpty(value))
                {
                    throw new Exception("hiba");
                }

                modell = value;
			}
		}

		private int ar;
		public int Ar
		{
			get { return ar; }
			set 
			{
				// [1, 5] -> 1, 2, 3, 4, 5
				// (1, 5] -> 2, 3, 4, 5
				// (2, 5) -> 3, 4

                // [100000, 50000000]
				if (value < 100000 || value > 50000000)
				{
					throw new Exception("Hiba");
				}

                ar = value; 
			}
		}

		private int evjarat;
		public int GetEvjarat()
		{
			return evjarat;
		}
		public void SetEvjarat(int value)
		{
			// [1950, jelenlegi év]

			if (value < 1950 || value > DateTime.Now.Year)
			{
				throw new Exception("Hiba");
			}

			evjarat = value;
		}

		private int km;
		public int Km
		{
			get { return km; }
			set 
			{ 
				if (value < 0)
				{
					throw new Exception("Hiba");
				}

				km = value; 
			}
		}

		// Mazda
        public Gepkocsi(string rendszam, string marka, string modell, int ar, int evjarat, int km)
        {
            Rendszam = rendszam;
            Marka = marka;
            Modell = modell;
            Ar = ar;
			SetEvjarat(evjarat);
            Km = km;
        }

		// Suzuki
        public Gepkocsi(string rendszam, string marka, string modell, int evjarat, int km) 
			: this(rendszam, marka, modell, 5000000, evjarat, km)
		{
        }

        public override string ToString()
        {
			//string eredmeny = Rendszam + ", " + ....
            return $"{Rendszam}, {Marka}: {Modell}, {Ar} ft, {GetEvjarat()}, {Km} km";
        }

		/*
		 * Gepkocsi g1 = new Gepkocsi("ABC-123");
		 * Gepkocsi g2 = new Gepkocsi("ABC-123");
		 * if (g1 == g2) { false
		 * }
		 */

        public override bool Equals(object? obj)
        {
			/*
			 * 1. null-e a másik példány (paraméter)
			 * 2. másik példány jó típusú-e
			 * 3. átalakítjuk a megfelő típusra
			 * 4. ellenőrizzük az összes mezőt
			 */
			if (obj is null || obj is not Gepkocsi)
			{
				return false;
			}
			Gepkocsi masik = obj as Gepkocsi;

			if (Rendszam == masik.Rendszam) // ...
			{
				return true;
			}

			return false;
        }

		public int CsokkentettAr()
		{
			double eredetiAr = Ar;

			int eletkor = DateTime.Now.Year - GetEvjarat();

			for (int i = 0; i < eletkor; i++)
			{
				//eredetiAr = eredetiAr - 1;
				//eredetiAr -= 1;

				//eredetiAr = eredetiAr - eredetiAr * 0.05;
				eredetiAr -= eredetiAr * 0.05;
			}

			// 5% -> * 0.05

			return 0;
		}
    }
}
