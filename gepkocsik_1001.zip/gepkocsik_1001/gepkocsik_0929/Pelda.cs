﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gepkocsik_0929
{
    internal class Pelda
    {

        int num;
        string text;

        public Pelda(int szam, string szoveg)
        {
            Console.WriteLine("1. param: " + szam);
            Console.WriteLine("2. param: " + szoveg);
            Console.WriteLine("nagy konstruktor");
            num = szam;
            text = szoveg;
        }

        public Pelda(string szoveg2) : this(5, szoveg2) // new Pelda(5, szoveg2)
        {
            Console.WriteLine("1. param: " + szoveg2);
            Console.WriteLine("kis konstruktor");
        }

    }
}
