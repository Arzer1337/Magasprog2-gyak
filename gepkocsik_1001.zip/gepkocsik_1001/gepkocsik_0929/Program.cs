﻿namespace gepkocsik_0929
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Gepkocsi mazda = new Gepkocsi("ABC123", "Mazda", "mx5", 3000000, 2000, 5000);

            Gepkocsi suzuki = new Gepkocsi("BBB111", "Suzuki", "swift", 2000, 200);
           

            Console.WriteLine(mazda.Ar);
            Console.WriteLine(suzuki.Ar);

            Pelda p = new Pelda("hello");

            Console.WriteLine(mazda);
            Console.WriteLine(suzuki);

            //int a = 5;
            //int b = 6;
            //if (mazda.Equals(suzuki))
            //{

            //}
            try
            {
                AutoKereskedes kereskedes = new AutoKereskedes("Egri Keresekedes");
                Gepkocsi kocsi1 = new Gepkocsi("ABC-123", "BMW", "X5", 2020, 50000);
                kereskedes.AddGepkocsi(kocsi1);
                kereskedes.AddGepkocsi(new Gepkocsi("XYZ456", "Chevrolet", "Lacetti", 10000000, 2004, 250000));
                Gepkocsi k3 = new Gepkocsi("ABC124", "Mazda", "2", 2005, 150000);
                kereskedes.AddGepkocsi(k3);

                Console.WriteLine($"A kereskedés neve: {kereskedes.Nev}");
                Console.WriteLine($"A legdrágább autó: {kereskedes.LegdragabbAuto}");
                Console.WriteLine($"A kocsik átlag ára: {kereskedes.AtlagAr()}");
                Console.WriteLine("A Mazdák a kereskedésben");
                foreach (Gepkocsi kocsi in kereskedes.MarkaSzures("Mazda"))
                {
                    Console.WriteLine(kocsi);
                }
                Console.WriteLine($"Az ABC-124 rendszámú kocsi: {kereskedes["ABC124"]}");
                Console.WriteLine($"A kereskedés: {kereskedes.ToString()}");
            } catch (Exception ex) {
                Console.WriteLine($"Valami hiba történt: {ex.Message}");
            }
        }
    }
}
