﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gepkocsik_0929
{
    internal class AutoKereskedes
    {
		private string nev;
		public string Nev
		{
			get { return nev; }
			set 
			{ 
				if (string.IsNullOrEmpty(value))
				{
					throw new Exception("hiba");
				}

				nev = value; 
			}
		}

		public List<Gepkocsi> gepkocsik;

		/*
		 * AutoKereskedes bmwKereskedes = new AutoKereskedes();
		 * ......
		 * Console.WriteLine(bmwKereskedes.LegdragabbAuto);
		 * 
		 * 
		 * try {
		 * 
		 * } catch (Exception) {
		 * }
		 */

		public Gepkocsi LegdragabbAuto
		{
			get
			{
				if (gepkocsik.Count == 0)
				{
					throw new Exception("Nincsen egyetlen autó sem a kereskedésben!");
				}

				Gepkocsi legdragabb = gepkocsik[0];

				foreach (Gepkocsi kocsi in gepkocsik)
				{
					if (kocsi.Ar > legdragabb.Ar)
					{
						legdragabb = kocsi;
					}
				}

				return legdragabb;
			}
		}

        public AutoKereskedes(string nev)
        {
			Nev = nev;
			gepkocsik = new List<Gepkocsi>(); // inicializálás
        }

		public void AddGepkocsi(Gepkocsi ujGepkocsi)
		{
			gepkocsik.Add(ujGepkocsi);
		}

		//public void DeleteGepkocsi(Gepkocsi torlendo)
		//{
		//	foreach (Gepkocsi gepkocsi in gepkocsik)
		//	{
		//		if (gepkocsi.Rendszam == torlendo.Rendszam) // TODO equals
		//		{
		//			gepkocsik.Remove(gepkocsi);
		//			return;
		//		}
		//	}

		//	throw new Exception("Nem talált ilyen autót");
		//}

		public void DeleteGepkocsi(Gepkocsi torlendo)
		{
			if (gepkocsik.Contains(torlendo)) // equalst használja
            {
				gepkocsik.Remove(torlendo);
			}
			else
			{
				throw new Exception("Nincs ilyen");
			}
		}

		public void DeleteGepkocsiRovidebb(Gepkocsi torlendo)
		{
			if (gepkocsik.Remove(torlendo) == false)
			{
				throw new Exception("Nincs ilyen");
			}
		}

		public double AtlagAr()
		{
			int osszeg = 0;
			foreach (Gepkocsi kocsi in gepkocsik)
			{
				osszeg += kocsi.Ar;
			}
			return osszeg / gepkocsik.Count;
		}

		public List<Gepkocsi> MarkaSzures(string marka)
		{
			List<Gepkocsi> markasGepkocsik = new List<Gepkocsi>();

			foreach (Gepkocsi kocsi in gepkocsik)
			{
				if (kocsi.Marka == marka)
				{
					markasGepkocsik.Add(kocsi);
				}
			}

			return markasGepkocsik;
		}

		/*
		 * List<int> jegyek = [1, 2, 4, 5, 1, 5];
		 * jegyek[0]
		 * 
		 * Dictionary<string, int> nevhezJegyek = {"Máté": 2, "Szabi": 5};
		 * nevhezJegyek["Szabi"]
		 * 
		 * bmwKereskedes["ABC-123"]
		 */
		public Gepkocsi this[string rendszam]
		{
			get
			{
				foreach (Gepkocsi kocsi in gepkocsik)
				{
					if (kocsi.Rendszam == rendszam)
					{
						return kocsi;
					}
				}

				return null;
			}
		}

        public override string ToString()
        {
			string eredmeny = $"{Nev}, ";

			foreach (Gepkocsi kocsi in gepkocsik)
			{
				eredmeny += $"{kocsi.ToString()}, ";
			}

			return eredmeny;
        }
    }
}
